package disruptor;

import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

import com.lmax.disruptor.RingBuffer;
import com.lmax.disruptor.dsl.Disruptor;

import disruptor2.LongEvent;
import disruptor2.LongEventHandler;
import disruptor2.LongEventProducer;

public class Main {
	@SuppressWarnings("unchecked")
	public static void main(String[] args) {
		 Executor executor = Executors.newCachedThreadPool();
		 CompanyInitEventFactory f = new CompanyInitEventFactory();
		 int bufferSize = 1024;
		 Disruptor<CompanyInitEvent> disruptor = new Disruptor<CompanyInitEvent>(f, bufferSize, executor);
		 disruptor.handleEventsWith(new CompanyInitConsumer());
		 disruptor.start();
		 RingBuffer<CompanyInitEvent> ringBuffer = disruptor.getRingBuffer();
		 
		 CompanyInitProducer producer = new CompanyInitProducer(ringBuffer);
		 //开始循环生产
		 for (int i = 0; i < 10; i++) {
			 Company c = new Company();
			 c.setName("哈士奇："+i);
			 
			 OperatorB2B o = new OperatorB2B();
			 o.setId(Long.parseLong(""+i));
			 producer.onData(c,o);
		}
		 
	}
}
